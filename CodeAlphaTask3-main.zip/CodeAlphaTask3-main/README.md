# CodeAlphaTask3 : Machine Learning
Task : " Handwritten Character Recognition "  Create a handwritten character recognition system that can recognize various handwritten characters or alphabets. 
